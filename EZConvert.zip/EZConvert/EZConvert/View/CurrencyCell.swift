import UIKit

class CurrencyCell: UITableViewCell {
    
    @IBOutlet weak var codeLabel: UILabel!
    @IBOutlet weak var moneyLabel: UILabel!
    @IBOutlet weak var flagImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!

    var currencyTableView = CurrencyTableView()
    var exchangeRates: [String: Double] = [:]
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupFlagImage()
        moneyLabel.text = "0.00"
    }

    private func setupFlagImage() {
        let sideLength: CGFloat = 110
        flagImage.frame = CGRect(x: 10, y: 20, width: sideLength, height: sideLength)
        flagImage.layer.cornerRadius = sideLength / 4.5
        flagImage.layer.masksToBounds = true
        flagImage.layer.borderWidth = 4
        flagImage.layer.borderColor = UIColor.white.cgColor
    }

    func updateMoneyLabel(with amount: Double) {
        moneyLabel.text = String(format: "%.2f", amount)
    }

    func convertAmount(baseAmount: Double, baseCurrency: String) {
        guard let resultCurrencyCode = codeLabel.text,
              let baseRate = exchangeRates[baseCurrency],
              let resultRate = exchangeRates[resultCurrencyCode] else {
            return
        }
        
        let convertedAmount = (baseAmount * resultRate) / baseRate
        updateMoneyLabel(with: convertedAmount)
    }

    func configureCell(code: String, name: String) {
        codeLabel.text = code
        nameLabel.text = name
        configureFlagImage(for: code)
    }

    private func configureFlagImage(for currencyCode: String) {
        flagImage.image = UIImage(named: "\(currencyCode).png") ?? UIImage(named: "placeholder.png")
    }
}
