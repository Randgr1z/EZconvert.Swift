//
//  CurrencyTabelView.swift
//  EZConvert
//
//  Created by Intorn Siwaleeponlap on 5/10/2567 BE.
//

import UIKit

class CurrencyTableView: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var currencyButton: UIButton!
    @IBOutlet weak var moneyLabel: UITextField!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var flagImage: UIImageView!
    
    var selectedBaseCurrency: String?
    var currencyManager = CurrencyManager()
    var lastEnteredAmount: Double = 0.0
    
    let menuItems = C.array
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupToolbar(for: moneyLabel)
        setupView()
        setupTableView()
        currencyManager.delegate = self
        moneyLabel.delegate = self
        moneyLabel.addTarget(self, action: #selector(moneyAmountChanged), for: .editingChanged)
    }
    
    private func setupView() {
        selectedBaseCurrency = "USD"
        currencyManager.getCurrencyExchange(for: selectedBaseCurrency!)
        nameLabel.text = "Select Currency"
        currencyButton.setTitle("???", for: .normal) // Set the button title to USD
        configureFlagImage(flagImage, for: "")
    }
    
    private func setupTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "CurrencyCell", bundle: nil), forCellReuseIdentifier: "DataCell")
    }
    
    private func setupToolbar(for textField: UITextField) {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneButtonTapped))
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolbar.setItems([flexibleSpace, doneButton], animated: false)
        textField.inputAccessoryView = toolbar
    }
    
    @objc func doneButtonTapped() {
        moneyLabel.resignFirstResponder()
    }
    
    @objc private func moneyAmountChanged() {
        // Ensure that the text is a valid double
        guard let baseAmountText = moneyLabel.text, let baseAmount = Double(baseAmountText) else {
            lastEnteredAmount = 0.0
            updateConvertedAmounts()
            return
        }
        lastEnteredAmount = baseAmount
        updateConvertedAmounts(with: moneyLabel.text ?? "")
    }
    
    
    private func updateConvertedAmounts() {
        guard let baseCurrencyCode = selectedBaseCurrency else { return }
        
        for cell in tableView.visibleCells as? [CurrencyCell] ?? [] {
            cell.exchangeRates = currencyManager.exchangeRates
            cell.convertAmount(baseAmount: lastEnteredAmount, baseCurrency: baseCurrencyCode)
        }
    }
    
    private func configureFlagImage(_ imageView: UIImageView, for currencyCode: String) {
        let sideLength: CGFloat = 110
        imageView.image = UIImage(named: "\(currencyCode).png") ?? UIImage(named: "placeholder.png")
        imageView.frame = CGRect(x: 10, y: 20, width: sideLength, height: sideLength)
        imageView.layer.cornerRadius = sideLength / 4.5
        imageView.layer.masksToBounds = true
        imageView.layer.borderWidth = 4
        imageView.layer.borderColor = UIColor.white.cgColor
        imageView.contentMode = .scaleAspectFill
    }
    
    @IBAction func currencyPickButton(_ sender: UIButton) {
        let alertController = UIAlertController(title: "Select Currency", message: nil, preferredStyle: .actionSheet)
        
        for item in menuItems {
            alertController.addAction(UIAlertAction(title: item.name, style: .default, handler: { _ in
                self.updateSelectedCurrency(item)
            }))
        }
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    
    private func updateSelectedCurrency(_ item: (code: String, name: String)) {
        currencyButton.setTitle(item.code, for: .normal)
        flagImage.image = UIImage(named: "\(item.code).png") ?? UIImage(named: "placeholder.png")
        nameLabel.text = item.name
        selectedBaseCurrency = item.code
        currencyManager.getCurrencyExchange(for: item.code)
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.text = ""
    }
    
    // Handle changes in text fields
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentText = textField.text ?? ""
        let updatedText = (currentText as NSString).replacingCharacters(in: range, with: string)
        
        // Update the amount for conversion
        updateConvertedAmounts(with: updatedText)
        
        return true
    }
    
    private func updateConvertedAmounts(with baseAmountString: String) {
        guard let baseAmount = Double(baseAmountString) else {
            lastEnteredAmount = 0.0
            updateAllCells(with: lastEnteredAmount)
            return
        }
        
        lastEnteredAmount = baseAmount
        updateAllCells(with: lastEnteredAmount)
    }
    
    private func updateAllCells(with amount: Double) {
        guard let baseCurrencyCode = selectedBaseCurrency else { return }
        
        for cell in tableView.visibleCells as? [CurrencyCell] ?? [] {
            cell.exchangeRates = currencyManager.exchangeRates
            cell.convertAmount(baseAmount: amount, baseCurrency: baseCurrencyCode)
        }
    }
    
}

    // MARK: - CurrencyManagerDelegate
    extension CurrencyTableView: CurrencyManagerDelegate {
        func didUpdateExchange(base: String, rates: [String: Double]) {
            DispatchQueue.main.async {
                self.currencyManager.exchangeRates = rates
                self.updateConvertedAmounts() // Update amounts after getting new rates
                self.tableView.reloadData()
            }
        }

        func didFailWithError(error: Error) {
            print("Failed to fetch exchange rates: \(error.localizedDescription)")
        }
    }

    // MARK: - UITableViewDataSource
    extension CurrencyTableView: UITableViewDataSource {
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return menuItems.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "DataCell", for: indexPath) as! CurrencyCell
            let currency = menuItems[indexPath.row]
            cell.configureCell(code: currency.code, name: currency.name)
            
            // Maintain updated conversion
            if let baseCurrency = selectedBaseCurrency {
                cell.exchangeRates = currencyManager.exchangeRates
                cell.convertAmount(baseAmount: lastEnteredAmount, baseCurrency: baseCurrency)
            }
            
            return cell
        }
    }

    // MARK: - UITableViewDelegate
extension CurrencyTableView: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedCurrency = menuItems[indexPath.row]
        print("Selected Currency: \(selectedCurrency)")
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
