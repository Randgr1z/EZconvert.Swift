import UIKit

class ConvertViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var baseCurrencyTextField: UITextField!
    @IBOutlet weak var flagsImage: UIImageView!
    @IBOutlet weak var currencyButton: UIButton!
    
    
    @IBOutlet weak var exchangeCurrencyTextField: UITextField!
    @IBOutlet weak var secondCurrencyButton: UIButton!
    @IBOutlet weak var secondFlagImage: UIImageView!
    @IBOutlet weak var nameFirstCurrencyLabel: UILabel!
    @IBOutlet weak var nameSecondCurrencyLabel: UILabel!
    
    var currencyManager = CurrencyManager()
    var selectedBaseCurrency: String?
    var selectedResultCurrency: String?
    var exchangeRates: [String: Double] = [:]
    
    
    let menuItems = C.array
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupToolbar(for: baseCurrencyTextField)
            
            // Set up the toolbar for exchangeCurrencyTextField
        setupToolbar(for: exchangeCurrencyTextField)
            
        currencyManager.delegate = self
        
        currencyManager.delegate = self
        
        // Set delegates
        baseCurrencyTextField.delegate = self
        exchangeCurrencyTextField.delegate = self
        
        // Initial setup
        nameFirstCurrencyLabel.text = "United States Dollar"
        nameSecondCurrencyLabel.text = "United States Dollar"
        
        // Configure flag images
        configureFlagImage(flagsImage, for: "USD")
        configureFlagImage(secondFlagImage, for: "USD")
        
        // Set default selected currencies
        selectedBaseCurrency = "USD"
        selectedResultCurrency = "USD"
        
        exchangeCurrencyTextField.placeholder = "0.00"
        
        // Fetch initial exchange rates for USD
        currencyManager.getCurrencyExchange(for: "USD")
    }
    
    private func setupToolbar(for textField: UITextField) {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        // Create a Done button
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneButtonTapped))
        
        // Create a flexible space item to push the Done button to the right
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        
        // Add the Done button and the flexible space item to the toolbar
        toolbar.setItems([flexibleSpace, doneButton], animated: false)
        
        // Set the toolbar as the inputAccessoryView for the text field
        textField.inputAccessoryView = toolbar
    }

    @objc func doneButtonTapped() {
        // Dismiss the keyboard
        baseCurrencyTextField.resignFirstResponder()
        exchangeCurrencyTextField.resignFirstResponder()
    }
    
    func configureFlagImage(_ imageView: UIImageView, for currencyCode: String) {
        let sideLength: CGFloat = 105
        imageView.image = UIImage(named: "\(currencyCode).png")
        imageView.frame = CGRect(x: 10, y: 20, width: sideLength, height: sideLength)
        imageView.layer.cornerRadius = sideLength / 5
        imageView.layer.masksToBounds = true
        imageView.layer.borderWidth = 3
        imageView.layer.borderColor = UIColor.white.cgColor
        imageView.contentMode = .redraw
    }
    
    func updateExchangeTextField(with baseCurrency: String) {
        guard let baseMoney = Double(baseCurrency), baseMoney >= 0 else {
            exchangeCurrencyTextField.placeholder = "0.00"
            return
        }
        
        guard let baseCurrencyCode = selectedBaseCurrency,
              let resultCurrencyCode = selectedResultCurrency,
              let baseRate = exchangeRates[baseCurrencyCode],
              let resultRate = exchangeRates[resultCurrencyCode] else {
            // Do not display an error message if no rates are available yet
            exchangeCurrencyTextField.text = String(format: "%.2f", baseMoney) // Just return the input
            return
        }
        
        let convertedAmount = (baseMoney * resultRate) / baseRate
        exchangeCurrencyTextField.text = String(format: "%.2f", convertedAmount)
    }
    
    func updateBaseTextField(with exchangeCurrency: String) {
        guard let exchangeMoney = Double(exchangeCurrency), exchangeMoney >= 0 else {
            baseCurrencyTextField.text = "0.00"
            return
        }
        
        guard let baseCurrencyCode = selectedResultCurrency,
              let resultCurrencyCode = selectedBaseCurrency,
              let baseRate = exchangeRates[baseCurrencyCode],
              let resultRate = exchangeRates[resultCurrencyCode] else {
            // Do not display an error message if no rates are available yet
            baseCurrencyTextField.text = String(format: "%.2f", exchangeMoney) // Just return the input
            return
        }
        
        let convertedAmount = (exchangeMoney * resultRate) / baseRate
        baseCurrencyTextField.text = String(format: "%.2f", convertedAmount)
    }
    
    @IBAction func firstCurrencyButton(_ sender: UIButton) {
        let alertController = UIAlertController(title: "Select Currency", message: nil, preferredStyle: .actionSheet)
        
        for item in menuItems {
            alertController.addAction(UIAlertAction(title: item.name, style: .default, handler: { _ in
                self.currencyButton.setTitle(item.code, for: .normal)
                self.currencyButton.titleLabel?.adjustsFontSizeToFitWidth = true
                self.flagsImage.image = UIImage(named: "\(item.code).png")
                self.nameFirstCurrencyLabel.text = item.name
                self.selectedBaseCurrency = item.code
                self.currencyManager.getCurrencyExchange(for: item.code)
            }))
        }
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func secondCurrencyButton(_ sender: UIButton) {
        let alertController = UIAlertController(title: "Select Currency", message: nil, preferredStyle: .actionSheet)
        
        for item in menuItems {
            alertController.addAction(UIAlertAction(title: item.name, style: .default, handler: { _ in
                self.secondCurrencyButton.setTitle(item.code, for: .normal)
                self.secondCurrencyButton.titleLabel?.adjustsFontSizeToFitWidth = true
                self.secondFlagImage.image = UIImage(named: "\(item.code).png")
                self.nameSecondCurrencyLabel.text = item.name
                self.selectedResultCurrency = item.code
                self.currencyManager.getCurrencyExchange(for: item.code)
            }))
        }
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    
    
    //MARK: - text field
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        // Clear the text when the text field is tapped
        textField.text = ""
    }

    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // For base currency text field
        if textField == baseCurrencyTextField {
            let currentText = textField.text ?? ""
            let updatedText = (currentText as NSString).replacingCharacters(in: range, with: string)
            updateExchangeTextField(with: updatedText)
        }
        
        // For exchange currency text field
        if textField == exchangeCurrencyTextField {
            let currentText = textField.text ?? ""
            let updatedText = (currentText as NSString).replacingCharacters(in: range, with: string)
            updateBaseTextField(with: updatedText)
        }
        
        return true
    }
    
}
    
    // MARK: - ExchangeManagerDelegate
    
extension ConvertViewController: CurrencyManagerDelegate {
    func didUpdateExchange(base: String, rates: [String: Double]) {
        DispatchQueue.main.async {
            self.exchangeRates = rates
            
            if let baseCurrencyText = self.baseCurrencyTextField.text,
               let selectedBaseCurrency = self.selectedBaseCurrency,
               let selectedResultCurrency = self.selectedResultCurrency {
                self.updateExchangeTextField(with: baseCurrencyText)
            }
        }
    }
    
    func didFailWithError(error: Error) {
        print(error)
    }
}

