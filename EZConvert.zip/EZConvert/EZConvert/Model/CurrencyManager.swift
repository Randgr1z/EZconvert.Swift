//
//  CurrencyManager.swift
//  EZConvert
//
//  Created by Intorn Siwaleeponlap on 28/9/2567 BE.
//

import Foundation

protocol CurrencyManagerDelegate {
    func didUpdateExchange(base: String, rates: [String: Double])
    func didFailWithError(error: Error)
}

struct CurrencyManager {
    var delegate: CurrencyManagerDelegate?
    
    var exchangeRates: [String: Double] = [:]
    
    let baseURL = "https://v6.exchangerate-api.com/v6"
    let apiKey = "" // Your API
    let Currency = C.array
    func getCurrencyExchange(for baseCurrency: String) {
        let urlString = "\(baseURL)/\(apiKey)/latest/\(baseCurrency)"
        performRequest(urlString: urlString)
    }
    func performRequest(urlString: String) {
        if let url = URL(string: urlString) {
            let session = URLSession(configuration: .default)
            
            let task = session.dataTask(with: url) { (data, response, error) in
                if error != nil {
                    self.delegate?.didFailWithError(error: error!)
                    return
                }
                if let safeData = data {
                    if let jsonString = String(data: safeData, encoding: .utf8) {
                        print("Response: \(jsonString)") // Debugging line
                    }
                    self.parseJSON(currencyData: safeData)
                }
            }

            task.resume()
        }
    }
    
    func parseJSON(currencyData: Data) {
        let decoder = JSONDecoder()
        do {
            let decodedData = try decoder.decode(CurrencyData.self, from: currencyData)
            let rates = decodedData.conversionRates // Directly access the rates
            self.delegate?.didUpdateExchange(base: decodedData.baseCode, rates: rates)
        } catch {
            self.delegate?.didFailWithError(error: error)
        }
    }
}
